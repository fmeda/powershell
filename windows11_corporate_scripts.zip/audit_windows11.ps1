# Audit Script for Windows 11 Corporate Environment
# Author: Fabiano Aparecido
# Version: 1.0

param(
    [string]$OutputPath = "C:\AuditReport.txt"
)

Write-Host "[*] Starting Windows 11 Corporate Audit..."

$report = @()

# System Info
$report += "=== SYSTEM INFO ==="
$report += (Get-ComputerInfo | Out-String)

# Installed Software
$report += "=== INSTALLED SOFTWARE ==="
$report += (Get-WmiObject -Class Win32_Product | Select-Object Name, Version | Out-String)

# Running Processes
$report += "=== RUNNING PROCESSES ==="
$report += (Get-Process | Select-Object Name, Id, CPU, WS | Out-String)

# Network Config
$report += "=== NETWORK CONFIGURATION ==="
$report += (Get-NetIPAddress | Out-String)

# Firewall Status
$report += "=== FIREWALL STATUS ==="
$report += (Get-NetFirewallProfile | Out-String)

# Save Report
$report | Out-File -FilePath $OutputPath -Encoding UTF8

Write-Host "[+] Audit completed. Report saved to $OutputPath"
