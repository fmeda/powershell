# Security Hardening Script for Windows 11 Corporate
# Author: Fabiano Aparecido
# Version: 1.0

Write-Host "[*] Starting Security Hardening..."

# Enable Firewall
Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled True
Write-Host "[+] Firewall Enabled"

# Enable Windows Defender Real-Time Protection
Set-MpPreference -DisableRealtimeMonitoring $false
Write-Host "[+] Windows Defender Real-Time Protection Enabled"

# Enable Controlled Folder Access (Ransomware Protection)
Set-MpPreference -EnableControlledFolderAccess Enabled
Write-Host "[+] Controlled Folder Access Enabled"

# Force Windows Update
Write-Host "[*] Forcing Windows Update..."
Install-WindowsUpdate -AcceptAll -AutoReboot

# Audit Policy - Logon Events
auditpol /set /subcategory:"Logon" /success:enable /failure:enable
auditpol /set /subcategory:"Logoff" /success:enable /failure:enable
Write-Host "[+] Audit Policy Configured"

Write-Host "[+] Security Hardening Completed"
