# Monitoring Script for Windows 11 Corporate
# Author: Fabiano Aparecido
# Version: 1.0

param(
    [string]$LogFile = "C:\MonitoringLog.txt"
)

Write-Host "[*] Starting Monitoring..."

$log = @()

# CPU Usage
$cpu = Get-Counter '\Processor(_Total)\% Processor Time' | Select -ExpandProperty CounterSamples | Select -ExpandProperty CookedValue
$log += "CPU Usage: $cpu %"

# Memory Usage
$memory = Get-Counter '\Memory\Available MBytes' | Select -ExpandProperty CounterSamples | Select -ExpandProperty CookedValue
$log += "Available Memory: $memory MB"

# Disk Usage
$disk = Get-WmiObject Win32_LogicalDisk -Filter "DriveType=3" | Select-Object DeviceID,FreeSpace,Size
$log += "Disk Usage:"
$log += ($disk | Format-Table -AutoSize | Out-String)

# Save log
$log | Out-File -FilePath $LogFile -Encoding UTF8

Write-Host "[+] Monitoring data saved to $LogFile"
