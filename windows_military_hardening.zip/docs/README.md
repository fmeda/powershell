# Conteúdo de exemplo para docs/README.md
