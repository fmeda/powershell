# Conteúdo de exemplo para powershell/run_hardening.ps1
