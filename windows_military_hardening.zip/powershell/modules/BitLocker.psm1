# Conteúdo de exemplo para powershell/modules/BitLocker.psm1
