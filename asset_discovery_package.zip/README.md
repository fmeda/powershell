# Asset Discovery & Testing - CLI (Refatorado)

Resumo: solução modular para descoberta de ativos em redes locais e remotas, com integração planejada para Microsoft Sysinternals, execução assíncrona, parsers, Vault (placeholder) e playbook Ansible exemplo.

Quickstart:
1. Create a Python 3.9+ virtualenv.
2. `pip install -r requirements.txt`
3. Populate `tools/Sysinternals` with the Sysinternals suite (Autoruns.exe, PsExec.exe, sigcheck.exe).
4. Run: `python -m asset_discovery.ui.cli --mode preview` (or `safe` / `full`)

Notas de segurança:
- Execute scans somente com autorização formal.
- Use `--mode preview` para simular antes de executar.
