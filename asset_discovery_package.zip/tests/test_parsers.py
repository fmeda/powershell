import json
from asset_discovery.parsers.masscan import MasscanParser

def test_masscan_parser(tmp_path):
    sample = [{'ip': '10.0.0.1', 'ports': [{'port': 22}, {'port': 80}]}]
    p = tmp_path / 'm.json'
    p.write_text(json.dumps(sample), encoding='utf-8')

    out = MasscanParser.parse(str(p))
    assert isinstance(out, list)
    assert out[0]['ip'] == '10.0.0.1'
    assert 22 in out[0]['ports'] or 22 in [int(x) for x in out[0]['ports']]
