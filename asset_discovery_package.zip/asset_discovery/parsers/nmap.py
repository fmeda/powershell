"""Parser for Nmap XML outputs -> simplified JSON"""
import xmltodict
from typing import List, Dict, Any

class NmapParser:
    @staticmethod
    def parse(path: str) -> List[Dict[str, Any]]:
        with open(path, 'r', encoding='utf-8') as fh:
            doc = xmltodict.parse(fh.read())
        hosts = doc.get('nmaprun', {}).get('host', [])
        if isinstance(hosts, dict):
            hosts = [hosts]
        out = []
        for h in hosts:
            addr = h.get('address')
            ip = None
            if isinstance(addr, dict):
                ip = addr.get('@addr')
            elif isinstance(addr, list):
                ip = addr[0].get('@addr')
            ports = []
            for p in h.get('ports', {}).get('port', []) or []:
                ports.append({'port': int(p.get('@portid')), 'state': p.get('state', {}).get('@state')})
            out.append({'ip': ip, 'ports': ports})
        return out
