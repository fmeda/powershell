"""Parser for Masscan JSON outputs"""
import json
from typing import List, Dict, Any

class MasscanParser:
    @staticmethod
    def parse(path: str) -> List[Dict[str, Any]]:
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        out = []
        for e in data:
            out.append({'ip': e.get('ip'), 'ports': [p.get('port') for p in e.get('ports', [])]})
        return out
