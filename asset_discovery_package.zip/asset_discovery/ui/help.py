from rich.console import Console
from rich.panel import Panel
from rich.table import Table

def print_advanced_help():
    c = Console()
    tbl = Table(title="Advanced Help - Asset Discovery CLI", show_lines=True)
    tbl.add_column("Feature", style="cyan", no_wrap=True)
    tbl.add_column("Description", style="white")
    tbl.add_row("--mode preview", "Simula todos os comandos sem executar nada. 100% seguro.")
    tbl.add_row("--mode safe", "Executa comandos não destrutivos (nmap, masscan leve). Bloqueia PsExec prejudicial.")
    tbl.add_row("--mode full", "Executa TUDO. Inclui PsExec, Sysinternals, comandos remotos reais. Use com cautela.")
    tbl.add_row("Masscan", "Varredura de alta velocidade. Recomendado somente com autorização formal.")
    tbl.add_row("Nmap", "Fingerprinting, scripts NSE, auditoria detalhada de hosts.")
    tbl.add_row("Sysinternals", "Autoruns, Sigcheck, Process Explorer, coleta remota, análise forense.")
    tbl.add_row("Normalize", "Consolida JSON, XML e TXT em formato padronizado para SIEM.")
    tbl.add_row("Vault", "Integração opcional para segredos (HashiCorp Vault).") 
    tbl.add_row("JobStore", "Sistema de persistência para auditoria e repetibilidade de tarefas.")
    c.print(Panel(tbl, title="Advanced CLI Help", border_style="green"))
