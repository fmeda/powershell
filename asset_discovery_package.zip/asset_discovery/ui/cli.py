"""Rich-based CLI launcher wiring up executors, parsers and sysinternals."""
from __future__ import annotations
import asyncio
from rich.console import Console
from rich.prompt import Prompt
from asset_discovery.core.command_executor import CommandExecutor
from asset_discovery.core.sysinternals import SysinternalsExecutor
from asset_discovery.core.jobstore import JobStore
from asset_discovery.parsers.masscan import MasscanParser
from asset_discovery.parsers.nmap import NmapParser

console = Console()

class AssetCLI:
    def __init__(self, mode: str = 'preview'):
        self.executor = CommandExecutor(mode=mode)
        self.sys = SysinternalsExecutor('tools/Sysinternals', self.executor)
        self.store = JobStore()

    async def run(self):
        from rich.panel import Panel
        from rich.table import Table
        from rich import box
        console.print(Panel('[bold blue]Asset Discovery CLI[/bold blue]', box=box.ROUNDED))
        while True:
            table = Table(box=box.SIMPLE_HEAVY)
            table.add_column('Opção', style='cyan', width=8)
            table.add_column('Descrição', style='white')
            table.add_row('1', 'Masscan – Varredura rápida')
            table.add_row('2', 'Nmap – Varredura detalhada')
            table.add_row('3', 'Autoruns – Sysinternals')
            table.add_row('4', 'Normalize – Padronização de arquivos')
            table.add_row('H', 'Help Avançado')
            table.add_row('0', 'Sair')
            console.print(Panel(table, title='Menu Principal', border_style='green'))

            opt = Prompt.ask('Selecione uma opção', default='0')

            if opt == '1':
                targets = Prompt.ask('Targets (CIDR ou IPs separados por vírgula)')
                cmd = f'masscan {targets} -p0-65535 --rate=10000 -oJ outputs/masscan.json'
                res = await self.executor.run(cmd)
                console.print(res.stdout or res.stdout)

            elif opt == '2':
                hosts = Prompt.ask('Arquivo de hosts ou lista separada por vírgula')
                console.print('[yellow]Executando Nmap (preview/safe/full)...[/yellow]')
                # placeholder

            elif opt == '3':
                t = Prompt.ask('IP do host')
                res = await self.sys.autoruns_psexec(t)
                console.print(res)

            elif opt == '4':
                path = Prompt.ask('Caminho do arquivo (json/xml)')
                if path.endswith('.json'):
                    parsed = MasscanParser.parse(path)
                    console.print(parsed)
                elif path.endswith('.xml'):
                    parsed = NmapParser.parse(path)
                    console.print(parsed)
                else:
                    console.print('[red]Formato não suportado.[/red]')

            elif opt.upper() == 'H':
                from asset_discovery.ui.help import print_advanced_help
                print_advanced_help()

            elif opt == '0':
                console.print('[bold red]Saindo...[/bold red]')
                break

            else:
                console.print('[red]Opção inválida[/red]')

if __name__ == '__main__':
    import argparse, sys
    parser = argparse.ArgumentParser(description='Asset Discovery CLI - modular & async')
    parser.add_argument('--help-advanced', action='store_true', help='Exibe ajuda avançada detalhada')
    parser.add_argument('--mode', default='preview', choices=['preview','safe','full'])
    args = parser.parse_args()
    if args.help_advanced:
        from asset_discovery.ui.help import print_advanced_help
        print_advanced_help()
        sys.exit(0)

    cli = AssetCLI(mode=args.mode)
    asyncio.run(cli.run())
