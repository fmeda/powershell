"""Simple JSON job store for persistence of job metadata."""
import json
from pathlib import Path
from typing import List
from asset_discovery.core.command_executor import ExecResult

JOBS_DIR = Path('jobs')
JOBS_DIR.mkdir(parents=True, exist_ok=True)

class JobStore:
    def save(self, job_id: str, action: str, targets: list, result: ExecResult):
        p = JOBS_DIR / f'{job_id}.json'
        data = {
            'id': job_id,
            'action': action,
            'targets': targets,
            'mode': result.metadata.get('mode') if result.metadata else 'unknown',
            'returncode': result.returncode,
            'stdout': result.stdout,
            'stderr': result.stderr
        }
        with open(p, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, indent=2, ensure_ascii=False)

    def list(self) -> List[dict]:
        out = []
        for p in sorted(JOBS_DIR.glob('*.json')):
            with open(p, 'r', encoding='utf-8') as fh:
                out.append(json.load(fh))
        return out
