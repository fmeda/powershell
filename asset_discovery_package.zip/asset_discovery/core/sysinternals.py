\
"""Abstraction for running Sysinternals tools. Prefer WinRM (pywinrm) in production; PsExec as fallback.
This module implements both strategies as optional: if pywinrm is available and configured, uses it.
"""
from __future__ import annotations
from pathlib import Path
from typing import Optional

try:
    import winrm
    HAVE_WINRM = True
except Exception:
    HAVE_WINRM = False

from asset_discovery.core.command_executor import CommandExecutor

class SysinternalsExecutor:
    def __init__(self, tools_dir: str, executor: CommandExecutor):
        self.tools_dir = Path(tools_dir)
        self.executor = executor
        self.psexec = self.tools_dir / 'PsExec.exe'

    def _find_tool(self, name: str) -> Optional[Path]:
        p = self.tools_dir / name
        if p.exists():
            return p
        return None

    async def autoruns_psexec(self, target: str, args: str = '/accepteula -a'):
        exe = self._find_tool('Autoruns.exe')
        if not exe:
            return {'error': 'Autoruns.exe not found'}
        if not self.psexec.exists():
            return {'error': 'PsExec.exe not found'}
        out_file = Path('outputs') / f'{target}_autoruns.txt'
        cmd = f'\"{self.psexec}\" \\\\{target} -accepteula -s -i \"{exe}\" {args} > {out_file}'
        return await self.executor.run(cmd)

    async def autoruns_winrm(self, host: str, user: str, password: str, tool_args: str = '/accepteula -a'):
        if not HAVE_WINRM:
            return {'error': 'pywinrm not available'}
        session = winrm.Session(host, auth=(user, password))
        exe = str(self.tools_dir / 'Autoruns.exe')
        ps = f'{exe} {tool_args}'
        r = session.run_cmd(ps)
        return {'status_code': r.status_code, 'stdout': r.std_out.decode('utf-8'), 'stderr': r.std_err.decode('utf-8')}
