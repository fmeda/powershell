"""Command executor: sync + async wrapper around subprocess with preview/safe/full modes."""
from __future__ import annotations
import asyncio
import concurrent.futures
import shlex
import subprocess
import uuid
from dataclasses import dataclass
from typing import Dict, Any, Optional

@dataclass
class ExecResult:
    job_id: str
    returncode: Optional[int] = None
    stdout: Optional[str] = None
    stderr: Optional[str] = None
    metadata: Dict[str, Any] = None

class CommandExecutor:
    def __init__(self, mode: str = 'preview', max_workers: int = 8):
        assert mode in ('preview', 'safe', 'full')
        self.mode = mode
        self.pool = concurrent.futures.ThreadPoolExecutor(max_workers=max_workers)

    async def run(self, cmd: str, cwd: Optional[str] = None, timeout: int = 300) -> ExecResult:
        job_id = str(uuid.uuid4())
        if self.mode == 'preview':
            return ExecResult(job_id=job_id, stdout=f'[PREVIEW] {cmd}', metadata={'mode': 'preview'})

        def _run_blocking():
            try:
                proc = subprocess.run(shlex.split(cmd), stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=cwd, timeout=timeout)
                return proc.returncode, proc.stdout.decode('utf-8', errors='ignore'), proc.stderr.decode('utf-8', errors='ignore')
            except Exception as e:
                return -1, '', str(e)

        loop = asyncio.get_running_loop()
        rc, out, err = await loop.run_in_executor(self.pool, _run_blocking)
        return ExecResult(job_id=job_id, returncode=rc, stdout=out, stderr=err, metadata={'mode': self.mode})
