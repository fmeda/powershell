try:
    import hvac
    HAVE_HVAC = True
except Exception:
    HAVE_HVAC = False

class VaultClient:
    def __init__(self, url: str = None, token: str = None):
        if not HAVE_HVAC:
            self.client = None
            return
        self.client = hvac.Client(url=url, token=token)

    def get_secret(self, path: str):
        if not self.client:
            raise RuntimeError('hvac not available')
        data = self.client.secrets.kv.v2.read_secret_version(path=path)
        return data.get('data', {}).get('data')
